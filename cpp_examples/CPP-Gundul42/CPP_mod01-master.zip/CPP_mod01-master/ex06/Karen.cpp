/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Karen.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <graja@student.42wolfsburg.de>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/19 16:07:58 by graja             #+#    #+#             */
/*   Updated: 2021/12/19 18:19:53 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Karen.hpp"

void	Karen::_debug(void)
{
	std::cout << "[DEBUG]" << std::endl;
	std::cout << "I love to get extra bacon for my 7XL-double-cheese-triple";
	std::cout << std::endl;
	std::cout << "-pickle-ketchup burger. I just love it" << std::endl;
}

void	Karen::_info(void)
{
	std::cout << "[INFO]" << std::endl;
	std::cout << "I cannot believe adding extra bacon cost more money. You";
	std::cout << std::endl;
	std::cout << "don't put enough! If you did I would not have too ask"; 
	std::cout << std::endl;
	std::cout << "for it!" << std::endl;
}

void	Karen::_warning(void)
{
	std::cout << "[WARNING]" << std::endl;
	std::cout << "I think I deserve to have some extra bacon for free. I've";
	std::cout << std::endl;
	std::cout << "been coming here for years and you just started working"; 
	std::cout << std::endl;
	std::cout << "here last month." << std::endl;
}

void	Karen::_error(void)
{
	std::cout << "[ERROR]" << std::endl;
	std::cout << "This is unacceptable, I want to speak to the manager now.";
	std::cout << std::endl;
}

void	Karen::complain(std::string level)
{
	void		(Karen::*ptr[4])(void) ;
	std::string	check[4] = {"debug", "info", "warning", "error"};
	int			i;

	ptr[0] = &Karen::_debug;
	ptr[1] = &Karen::_info;
	ptr[2] = &Karen::_warning;
	ptr[3] = &Karen::_error;
	i = 0;
	while (i < 4)
	{
		if (level == check[i])
			break;
		i++;
	}
	switch (i)
	{
		case 4	:
			std::cout << "[Probably complaining about insignificant";
			std::cout << " problem]" << std::endl << std::endl;
			break ;

		default	:
			while (i < 4)
			{
				(this->*ptr[i])();
				std::cout << std::endl;
				i++;
			}
			break ;
	}
}
