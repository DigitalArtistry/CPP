# CPP_Mod00
42 project introducing CPP part00
